package pl.com.seremak.simplebills.planning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanningApplicationTests {

    @Test
    void contextLoads() {
    }

}
