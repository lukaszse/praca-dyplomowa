package pl.com.seremak.simplebills.planning.utils;

public class BillPlanConstants {

    public static final String MASTER_USER = "master_user";
}
