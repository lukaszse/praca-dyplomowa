package pl.com.seremak.simplebills.commons.constants;

public enum StandardCategories {

    UNDEFINED, ASSET
}
