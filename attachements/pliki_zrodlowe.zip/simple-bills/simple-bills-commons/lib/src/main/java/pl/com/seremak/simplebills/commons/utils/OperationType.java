package pl.com.seremak.simplebills.commons.utils;

public enum OperationType {

    CREATE,
    READ,
    UPDATE,
    DELETE
}
