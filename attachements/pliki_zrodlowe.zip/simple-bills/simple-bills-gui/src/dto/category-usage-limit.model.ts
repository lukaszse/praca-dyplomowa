export interface CategoryUsageLimitModel {
  username: string;
  categoryName: string;
  limit: number;
  usage: number;
  yearMonth: string;
}
