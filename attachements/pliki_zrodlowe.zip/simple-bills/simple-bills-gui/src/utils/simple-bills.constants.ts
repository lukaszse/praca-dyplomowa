export const DATE_FORMAT = "yyyy-MM-dd";
export const LOCALE_EN = "en";
export const LOADING_STATUS_MSG = "...loading";


