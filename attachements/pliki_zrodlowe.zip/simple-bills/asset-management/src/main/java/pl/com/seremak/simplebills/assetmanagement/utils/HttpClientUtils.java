package pl.com.seremak.simplebills.assetmanagement.utils;

public class HttpClientUtils {

    public static final String URI_SEPARATOR = "/%s";
}
