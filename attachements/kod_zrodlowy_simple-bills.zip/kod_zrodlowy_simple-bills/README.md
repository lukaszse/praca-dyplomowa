# simple-bills
Aplikacja do zarządzania finansami domowymi napisana w ramach pracy inżynierskiej pod tytułem:\
**Projekt i implementacja aplikacji wspomagającejzarządzanie finansami domowymi**
