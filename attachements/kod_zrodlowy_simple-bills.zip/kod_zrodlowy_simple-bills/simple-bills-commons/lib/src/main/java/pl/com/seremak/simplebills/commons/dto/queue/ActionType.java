package pl.com.seremak.simplebills.commons.dto.queue;

public enum ActionType {
        CREATION, DELETION, UPDATE
}