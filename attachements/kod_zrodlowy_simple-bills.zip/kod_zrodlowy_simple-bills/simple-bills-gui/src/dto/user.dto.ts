export interface UserDto {
  preferredUsername?: string;
  name?: string
  givenName?: string
  familyName?: string
}
