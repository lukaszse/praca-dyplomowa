export interface BalanceModel {
  username: string;
  balance: number;
}
